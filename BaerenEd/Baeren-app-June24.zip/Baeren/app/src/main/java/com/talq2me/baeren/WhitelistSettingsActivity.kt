package com.talq2me.baeren

import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity


class WhitelistSettingsActivity : AppCompatActivity() {

    private val allowed = RewardManager.allowedApps

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0
        )

        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val cb = CheckBox(this).apply {
                text = ri.loadLabel(pm).toString()
                isChecked = allowed.contains(pkg)
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) allowed.add(pkg) else allowed.remove(pkg)
                }
            }
            layout.addView(cb)
        }

        val scroll = ScrollView(this).apply {
            addView(layout)
        }

        setContentView(scroll)
    }

    override fun onPause() {
        super.onPause()
        RewardManager.saveAllowedApps(this)
    }
}
