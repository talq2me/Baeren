package com.talq2me.baeren

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.talq2me.baeren.MainActivity

class LauncherActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var allowed: MutableSet<String>
    private var rewardRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        // Load saved whitelist
        RewardManager.loadAllowedApps(this)

        // Now initialize `allowed` from RewardManager
        allowed = RewardManager.allowedApps.toMutableSet()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FFFBEA"))
            setPadding(32, 32, 32, 32)
        }

        // ✅ Accessibility reminder block
        if (!isAccessibilityServiceEnabled()) {
            val reminder = Button(this).apply {
                text = "Enable Protection (Accessibility)"
                setBackgroundColor(0xFFE57373.toInt()) // red-ish
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    startActivity(intent)
                }
            }
            root.addView(reminder, 0) // add at top of layout
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val settingsButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                showPinPrompt()  // ✅ Ask for PIN before accessing settings
            }
        }

        topBar.addView(settingsButton)

        val webAppButton = Button(this).apply {
            text = "Baeren"
        }

        val appGrid = GridLayout(this).apply {
            columnCount = 3
            rowCount = 3
        }

        root.addView(topBar)
        root.addView(webAppButton)
        root.addView(appGrid)

        setContentView(root)

        refreshIcons(appGrid) // ✅ AFTER allowed is initialized
    }


    fun grantTemporaryAccess(pkg: String, minutes: Int) {
        allowed.add(pkg)
        refreshIcons(findViewById(android.R.id.content) as ViewGroup)

        rewardRunnable?.let { handler.removeCallbacks(it) }
        rewardRunnable = Runnable {
            allowed.remove(pkg)
            refreshIcons(findViewById(android.R.id.content) as ViewGroup)
            bringHome()
        }
        handler.postDelayed(rewardRunnable!!, minutes * 60 * 1000L)
    }

    private fun refreshIcons(container: ViewGroup) {
        container.removeAllViews()
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0
        )
        apps.filter { allowed.contains(it.activityInfo.packageName) }
            .forEach { ri ->
                val btn = ImageButton(this).apply {
                    setImageDrawable(ri.loadIcon(pm))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    background = null
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = 200
                        height = 200
                        setMargins(16, 16, 16, 16)
                    }
                    setOnClickListener {
                        if (ri.activityInfo.packageName == packageName) {
                            // Launch your web app (MainActivity)
                            val intent = Intent(this@LauncherActivity, MainActivity::class.java)
                            startActivity(intent)
                        } else {
                            // Launch other apps
                            val intent = packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName)
                            if (intent != null) {
                                startActivity(intent)
                            }
                        }
                    }

                }
                container.addView(btn)
            }
    }

    private fun launchApp(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show()
    }

    private fun bringHome() {
        val home = Intent(this, LauncherActivity::class.java)
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(home)
    }

    private fun showPinPrompt() {
        val pinInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Enter PIN"
        }

        AlertDialog.Builder(this)
            .setTitle("Parental Control")
            .setView(pinInput)
            .setPositiveButton("OK") { _, _ ->
                if (pinInput.text.toString() == "1234") { // Change to your real PIN
                    startActivity(Intent(this, WhitelistSettingsActivity::class.java))
                } else {
                    Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${AppBlockerService::class.java.name}"
        val enabledServices = android.provider.Settings.Secure.getString(
            contentResolver,
            android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return enabledServices.contains(expected)
    }


    override fun onBackPressed() {
        super.onBackPressed() /* ignore */ }
}
