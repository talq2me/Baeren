package com.talq2me.baeren

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

object RewardManager {
    val allowedApps = mutableSetOf("com.talq2me.baeren")
    private var timer: Handler? = null
    private var runnable: Runnable? = null

    fun grantAccess(context: Context, pkg: String, minutes: Int) {
        allowedApps.add(pkg)
        saveAllowedApps(context)

        runnable?.let { timer?.removeCallbacks(it) }
        timer = Handler(Looper.getMainLooper())
        runnable = Runnable {
            allowedApps.remove(pkg)
            saveAllowedApps(context)

            // 🚫 Try to kill the app's background processes
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            am.killBackgroundProcesses(pkg)

            // ✅ Return to launcher/home
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }
        timer?.postDelayed(runnable!!, minutes * 60 * 1000L)
    }

    fun isAllowed(pkg: String): Boolean = allowedApps.contains(pkg)


    fun saveAllowedApps(context: Context) {
        val prefs = context.getSharedPreferences("whitelist_prefs", Context.MODE_PRIVATE)
        prefs.edit().putStringSet("allowed", allowedApps).apply()
    }

    fun loadAllowedApps(context: Context) {
        val prefs = context.getSharedPreferences("whitelist_prefs", Context.MODE_PRIVATE)
        val stored = prefs.getStringSet("allowed", null)
        if (stored != null) {
            allowedApps.clear()
            allowedApps.addAll(stored)
        }
    }
}


