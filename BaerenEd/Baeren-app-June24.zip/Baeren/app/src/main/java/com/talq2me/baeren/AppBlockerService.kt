package com.talq2me.baeren

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockerService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkgName = event.packageName?.toString() ?: return

        // Ignore launcher and system UI
        if (pkgName == "com.android.systemui" || pkgName == packageName) {
            lastPackage = pkgName
            return
        }

        // 🚫 Block any app that's not allowed
        if (!RewardManager.isAllowed(pkgName)) {
            returnToLauncher()
        }

        lastPackage = pkgName
    }

    override fun onInterrupt() {}

    private fun returnToLauncher() {
        val intent = Intent(this, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }
}
