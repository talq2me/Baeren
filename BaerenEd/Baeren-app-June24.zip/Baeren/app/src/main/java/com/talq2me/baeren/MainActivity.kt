package com.talq2me.baeren

import android.content.Intent
import android.os.*
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.provider.Settings
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask for battery/overlay permissions
        maybeRequestBatteryOptimization()
        maybeRequestOverlayPermission()

        // Init TTS
        tts = TextToSpeech(this, this)

        // Init WebView
        webView = WebView(this)
        setContentView(webView)
        initWebView()

        // JS-to-Android bridge
        webView.addJavascriptInterface(TTSBridge(), "AndroidTTS")

        webView.loadUrl("https://talq2me.github.io/Baeren/index.html")
    }

    private fun initWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            userAgentString = "Mozilla/5.0 (Linux; Android 10; Pixel 3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
        }
        webView.clearCache(true)
        webView.clearHistory()
        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val url = request.url.toString()

                // Special: open Read Along app via Play Store
                if (url.contains("readalong.google.com")) {
                    openPlayStore("com.google.android.apps.seekh")
                    return true
                }

                // Custom intent:// reward launcher
                if (url.startsWith("intent://")) {
                    try {
                        val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        val pkg = intent.data?.getQueryParameter("pkg")
                        val minutes = intent.data?.getQueryParameter("minutes")?.toIntOrNull() ?: 10

                        if (pkg != null) {
                            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                            if (launchIntent != null) {
                                startActivity(launchIntent)
                                RewardManager.grantAccess(this@MainActivity, pkg, minutes)
                                Toast.makeText(this@MainActivity, "Launching $pkg for $minutes min", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "App not installed: $pkg", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Intent error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                    return true
                }

                return false
            }
        }
    }

    private fun openPlayStore(pkg: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
            intent.setPackage("com.android.vending")
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
        }
    }

    private fun maybeRequestBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun maybeRequestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, 1234)
        }
    }

    // TTS Setup
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        webView.evaluateJavascript("if (typeof onTTSFinish === 'function') { onTTSFinish(); }", null)
                    }
                }
                override fun onError(utteranceId: String?) {
                    runOnUiThread {
                        webView.evaluateJavascript("if (typeof onTTSFinish === 'function') { onTTSFinish(); }", null)
                    }
                }
            })
        }
    }

    inner class TTSBridge {
        @JavascriptInterface
        fun speak(text: String, lang: String) {
            val locale = when (lang.lowercase()) {
                "fr" -> Locale.FRENCH
                "en" -> Locale.US
                else -> Locale.US
            }
            if (tts.setLanguage(locale) == TextToSpeech.LANG_MISSING_DATA) {
                Toast.makeText(this@MainActivity, "Unsupported lang: $lang", Toast.LENGTH_SHORT).show()
                webView.evaluateJavascript("if (typeof onTTSFinish === 'function') { onTTSFinish(); }", null)
                return
            }

            val params = Bundle()
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            val utteranceId = "utt_${System.currentTimeMillis()}"
            tts.stop()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
